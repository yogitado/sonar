<?php
session_start();

include "html/headerHtml.html";
include "html/bodyHtml.html";
include "html/footerHtml.html";

?>