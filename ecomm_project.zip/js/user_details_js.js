function delete_user(value)
				{
				
				window.location="deleteuser_query.php?delete="+value;
				}