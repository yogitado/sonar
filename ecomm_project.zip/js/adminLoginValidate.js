// <![CDATA[
            
    var frmvalidator = new Validator("register");
    frmvalidator.EnableOnPageErrorDisplay();
    frmvalidator.EnableMsgsTogether();

    frmvalidator.addValidation("name","req","Please provide your name");
    
    frmvalidator.addValidation("password","req","Please provide a password");

    
	
	
// ]]>