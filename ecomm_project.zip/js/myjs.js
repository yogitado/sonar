$(document).ready(function() {
alert("hi");
    $('#example').dataTable();
} );

