<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
<title>Insert title here</title>
</head>
<body>
<!--<a href="html/loginAdmin.html">Admin Login </a>-->
<?php header("location:html/loginAdmin.html");?>
</body>
</html>