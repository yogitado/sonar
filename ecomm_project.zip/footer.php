<div id="footer">
Copyright © ALM_E-COM@cybage.com
</div>