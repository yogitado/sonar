<?php
include "html/adminHeader.html";
?>

      

     
	  
	  



<?php
echo '<div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2">';
include "adminBodyContent.php";

include "html/adminNavigation.html";
echo '</div>';
?>

	<?php

?>

<?php include "Footer.php"; ?>
