


<html>
<head>
<link rel="stylesheet" type="text/css" href="css/bodyCss.css">
</head>
<div id="body">
<form  action="AddressDetails.php" method="POST" style="text-align: center;font:xx-large;" theme="simple">
<pre>
	<b>Full Name : </b><input type="text" name="FullName" id="FullName"></br>
	<b>Mobile No.: </b><input type="text" name="Mobile" id="Mobile"><br/>
	<b>Address Details :</b><textarea name="Address" rows="10" cols="30" id="Address"></textarea>
	<b>State : </b><input type="text" name="State" id="State"><br/>
	<b>City : </b><input type="text" name="City" id="City"><br/>
	<b>Pin Code : </b><input type="number" name="PinCode" id="PinCode"><br/>
	</pre>
	<input type="submit" value="add detail">
	
	

</form>
</div>

</html>

