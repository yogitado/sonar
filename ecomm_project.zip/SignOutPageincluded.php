<?php
session_start();
session_destroy();


include "html/HeaderHtml.html";
include "html/BodyHtml.html";
include "html/FooterHtml.html";

?>