<!--
<div id="header">
<table style="width:100%">
  <tr>
	<td><h2 style="color:white"><A href="ProductViewPage.php">HOME</A></h2></td>
    <td><h2><a href="html/CustomerSupport.html"> Customer Support</a></h2></td>
	
   	<td><h2><a href="html/AboutUs.html"> About Us</a></h2></td>
	
	<td><h2><a href="html/loginAdmin.html"> Log OUT</a></h2></td>		

  </tr>
</table>
</div>

-->
   <nav class="navbar navbar-inverse navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">E-Commerce</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><A href="../adminDashbordIncluded.php">HOME</A></li>
            <li><a href="html/AboutUs.html"> About Us</a></li>
            <li><a href="AdminLogout.php"> Log OUT</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Search...">
          </form>
        </div>
      </div>
    </nav>