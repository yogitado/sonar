<?php
session_start();

include "html/HeaderHtml.html";
include "html/BodySuccessAddUserHtml.html";
include "html/FooterHtml.html";

?>