<?php
session_start();

include "html/HeaderHtml.html";
include "html/BodySignupHtml.html";
include "html/FooterHtml.html";

?>