<?php
// Declaring config class constants
class Config
 {
    const HOST     = '172.27.59.54',
          USER     = 'ecomm',
          PASSWORD = 'ecomm@123',
		
			HELPER = "Helper.php";
		 //LOCATION ='http://localhost:81/sample/emp.php';
          //ANOTHER_VAR = true;
} 
 
?>