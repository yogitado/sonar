<?php
/**
*The Config class is a class where you declare all the credential of your project
*
*Declaring config class constants
*/
class Config
 {
    const HOST     = '172.27.59.54',
          USER     = 'ecomm',
          PASSWORD = 'ecomm@123',
		
		HELPER = "Helper.php";
} 
?>