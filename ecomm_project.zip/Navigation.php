<div id="nav">
<a class="semi-transparent-button" href="add_product.php"> ADD </a><br/>
</div>